library(igraph)
set.seed(42)
rm(list = ls())

# Get files
files <- list.files("../02 - Datasets/")
files <- files[sapply(files, function(x) grepl("relationships", x, fixed = TRUE))]

# Calculate metrics
summary_table <- c()

for(i in files){
  relationships <- read.csv(paste0("../02 - Datasets/",i), sep = ",", stringsAsFactors = F)
  g <- graph_from_edgelist(as.matrix(relationships[,c("source","target")]), directed=T)
  row <- data.frame(case = i,
                    vcount = vcount(g), 
                    ecount = ecount(g), 
                    diameter = diameter(g), 
                    mean_distance = round(mean_distance(g),2),
                    mean_degree = round(mean(degree(g, normalized=TRUE)),2),
                    density = round(edge_density(g, loops = FALSE), 2),
                    centralization = round(centr_degree(g)$centralization,2))
  summary_table <- rbind(summary_table, row)
  rm(relationships, g)
}

# Calculate users
files <- list.files("../02 - Datasets/")
files <- files[sapply(files, function(x) grepl("users", x, fixed = TRUE))]

summary_table_2 <- c()
for(i in files){
  users <- read.csv(paste0("../02 - Datasets/",i), sep = ",", stringsAsFactors = F)
  row <- data.frame(case = i,
                    users = nrow(users))
  summary_table_2 <- rbind(summary_table_2, row)
}
